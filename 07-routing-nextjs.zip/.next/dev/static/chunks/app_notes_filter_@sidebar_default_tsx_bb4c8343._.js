(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/app_notes_filter_@sidebar_SidebarNotes_module_746a5b77.css"
],
    source: "dynamic"
});
