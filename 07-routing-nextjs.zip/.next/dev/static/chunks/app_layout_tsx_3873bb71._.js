(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_7532e85d._.js",
  "static/chunks/components_e67f1036._.js",
  "static/chunks/_5bc187d1._.css"
],
    source: "dynamic"
});
