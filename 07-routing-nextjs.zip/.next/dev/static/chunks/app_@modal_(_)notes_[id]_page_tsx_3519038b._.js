(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_fc011ca4._.js",
  "static/chunks/_6b7bb5af._.js",
  "static/chunks/components_56bab851._.css"
],
    source: "dynamic"
});
