module.exports = [
"[project]/.next-internal/server/app/@modal/(.)notes/[id]/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_%40modal_%28_%29notes_%5Bid%5D_page_actions_25f37291.js.map