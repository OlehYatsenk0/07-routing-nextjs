export default function ModalDefault() {
  // коли модальне вікно неактивне — нічого не показуємо
  return null;
}